<?php
//require dirname(__FILE__) . '/iSDK/isdk.php';
//require dirname(__FILE__) . '/config.php';
//require dirname(__FILE__) . '/error.class.php';
//require dirname(__FILE__) . '/revgo.php';
//
//$app = new iSDK();
//$app->cfgCon($is_app, $is_key);
//echo "<pre>".print_r($app->dsUpdate('Job', 47, array('_ordershipstatus' => 'yes')), true);

echo "What do you think you are doing?  This is not a valid place to be.";